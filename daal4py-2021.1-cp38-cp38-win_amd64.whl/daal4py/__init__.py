#!/usr/bin/env python
#===============================================================================
# Copyright 2014-2021 Intel Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#===============================================================================

#_LIBS = []
#
#import platform
#import ctypes
import os
import sys
##if "Windows" in platform.system():
#lib_names =[
#    "onedal.1.dll",
#    "onedal_core.1.dll",
#    "onedal_dpc.1.dll",
#    "onedal_sequential.1.dll",
#    "onedal_thread.1.dll",
#    "tbb12.dll",
#    "tbbbind.dll",
#    "tbbbind_2_0.dll",
#    "tbbmalloc.dll",
#    "tbbmalloc_proxy.dll"
#]
#
#sys.executable
path_to_libs = os.path.dirname(sys.executable) + "\\Library\\bin"
os.add_dll_directory(path_to_libs)
#list_dir = os.listdir(os.path.join(sys.executable, "Library/bin", )
#pathBackup = os.environ['PATH'].split(os.pathsep)
os.environ['PATH'] = path_to_libs+";"+os.environ.get('PATH')
            #pathBackup + [os.path.dirname(path_to_libs)])

#for l in lib_names:
#    try:
#        lib = ctypes.cdll.LoadLibrary(path_to_libs + l)
#        lib_success = True
#        _LIBS.append(lib)
#    except OSError as e:
#        continue
#    if not lib_success:
#        raise ImportError(f"{l} lib file not found in {path_to_libs}")

try:
    from _daal4py import *
    from _daal4py import _get__version__, _get__daal_link_version__, _get__daal_run_version__, __has_dist__
except ImportError as e:
    s = str(e)
    if 'libfabric' in s:
        raise ImportError(s + '\n\nActivating your conda environment or sourcing mpivars.[c]sh/psxevars.[c]sh may solve the issue.\n')
    raise

import logging
import warnings
import os
import sys
logLevel = os.environ.get("IDP_SKLEARN_VERBOSE")
try:
    if not logLevel is None:
        logging.basicConfig(stream=sys.stdout, format='%(levelname)s: %(message)s', level=logLevel.upper())
except:
    warnings.warn('Unknown level "{}" for logging.\n'
                    'Please, use one of "CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG".'.format(logLevel))
